package com.ashwilliams87.saitamachallenge.`interface`

interface MainContract {

    interface View {

//        val usdRatesSharedPreferences: UsdRates
//
//        fun setRates(rates: UsdRates)
//
//        fun saveRatesToSharedPreferences()
//
//        fun askUserForInternetConnection()
//
//        fun updateViewElements()
//
//        fun sendMessageCacheOld()
    }

    interface Presenter {

        fun loadTasks()

    }

    interface UsdRatesInteractor {

    }
}
